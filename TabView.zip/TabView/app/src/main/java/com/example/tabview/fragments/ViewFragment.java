package com.example.tabview.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.tabview.models.Contacts;
import com.example.tabview.R;
import com.example.tabview.acttivities.DeleteContactsActivity;
import com.example.tabview.acttivities.MainActivity;
import com.example.tabview.adapters.ContactsAdapter;
//import com.example.tabview.adapters.ContactsRecyclerAdapter;

import java.util.ArrayList;
import java.util.List;


public class ViewFragment extends Fragment {

    Button addUser,delContact;
    TextView textView;
    RecyclerView recyclerView;
    ArrayList<Contacts> contactsArrayList = new ArrayList<>();
    ContactsAdapter contactsRecyclerAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_view, container, false);

//        textView = view.findViewById(R.id.tv_read);
        delContact = view.findViewById(R.id.button_delete_contacts);
        delContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(view.getContext(), DeleteContactsActivity.class);
                v.getContext().startActivity(intent);
            }
        });
        recyclerView = view.findViewById(R.id.recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.addItemDecoration(new DividerItemDecoration(getContext(), DividerItemDecoration.VERTICAL));


        List<Contacts> contacts = MainActivity.contactsDatabase.contactsDAO().getAllContacts();

        contactsArrayList.addAll(contacts);
        contactsRecyclerAdapter = new ContactsAdapter(getContext(), contactsArrayList);
        recyclerView.setAdapter(contactsRecyclerAdapter);

        return view;

    }

}